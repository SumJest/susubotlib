## Library for SUSU's bots

### !!If you don't know what is it you don't need this.!!

### In other cases

...


Roman Fakhrutdinov